echo 'Script with error handling'
